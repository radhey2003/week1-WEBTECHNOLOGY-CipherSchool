# Lecture 55 - Chapter three exercise 3
n = int(input("enter a number: "))
sum = 0 
i = 1
while i<=n:
    sum += i
    i += 1
print(sum)
