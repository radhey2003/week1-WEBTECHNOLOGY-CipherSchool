# Lecture 42 and 43 and 44 - If statement , pass statement , if-else statement

age = int(input())
if age>=14:
    print("you are above 14")



# Lecture 43
x=18
if x>18:
    pass


# Lecture 44
age = int(input())
if age>=14:
    print("you are above 14")
else:
    print("not eligible")

