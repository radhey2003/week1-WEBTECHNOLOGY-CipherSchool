# Lecture 40 - Assignment operatiors
name = "harsh"
name = name + "it" #name  += "it"
print(name)
age=20 
age += 1
print(age)

