number_1 = int(input("enter number 1: "))
num_2 = int(input("enter number 2: "))
num_3 = int(input("enter number 3: "))
print(f"{number_1+num_2+num_3 / 3}")