# Lecture 47 - And or operator in python
name = 'abc'
age = 18
if name == 'abc' and age==18:
    print("condition true")
else:
    print("condition false")

# Or operatoer (if one is true then output is true)
if name == 'abc' or age==18:
    print("condition true")
else:
    print("condition false")
    