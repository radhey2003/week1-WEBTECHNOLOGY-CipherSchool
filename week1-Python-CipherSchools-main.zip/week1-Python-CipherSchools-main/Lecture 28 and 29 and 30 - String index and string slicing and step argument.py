# Lecture 28 and 29 and 30 - String indexing and string slicing and step argument
language = "Python"
print(language[2])

# Lecture 29
lang = "Python"
print(lang[0:2])

# Lecture 30
print("Sandarbh"[0:5:2]) 
print("Sandarbh"[5::-1])
print("Sandarbh"[-1::-1])