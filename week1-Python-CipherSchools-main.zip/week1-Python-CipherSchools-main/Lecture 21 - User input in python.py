# user input
# input function
name = input("type your name")
print("hello"+name)
#string
age=input("what is your age?")
#24 , "24"
print("your age is "+age)
