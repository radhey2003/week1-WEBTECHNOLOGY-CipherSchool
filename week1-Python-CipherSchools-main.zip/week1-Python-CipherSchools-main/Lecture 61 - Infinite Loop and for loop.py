# Lecture 61 and 62 : Infinite loop and For loop
i = 1
while i <=10:
    print("Hello world")
    i += 1

#Lecture 62 
for i in range(1,11):
    print(f"Hello world : {i}")
    print("this is line \n")