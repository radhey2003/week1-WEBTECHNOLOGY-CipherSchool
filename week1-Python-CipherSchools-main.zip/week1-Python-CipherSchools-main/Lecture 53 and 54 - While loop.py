# LEcture 53 and 54 - While loop and sum of numbers
#print("hello world") #10 times
i=1
while i<=10:
    print("Hello world")
    i = i+1

# Lecture 54
total = 0
i = 1
while i<=10:
    total = total + i
    i = i+ 1
print(total)    