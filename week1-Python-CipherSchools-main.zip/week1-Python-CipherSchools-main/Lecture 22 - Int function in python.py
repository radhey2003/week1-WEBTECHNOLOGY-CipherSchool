("number_one = int(input("enter first number")) #4
number_two = int(input("enter second number")) #4
total = number_one+number_two #8
print("total is" + str(total))
# total = "4"+"4"=44

number_1=str(4)
number_2=float("44")
number_3=int("33")
print(number_2+number_3) #float