# Question 1
print("this is \\\ double backslash")
# Question 2
print("/\\/\\/\\/\\/\\")
# Question 3
print("he is    awesome")
# Question 4
print(" \\\" \\n \\t \\\' ")