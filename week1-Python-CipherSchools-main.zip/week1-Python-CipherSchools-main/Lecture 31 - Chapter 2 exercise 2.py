# Lecture 31 - Chapter 2 exercise 2
username = input("enter your name = ")
reverse = username[::-1]
print(f"{reverse}")